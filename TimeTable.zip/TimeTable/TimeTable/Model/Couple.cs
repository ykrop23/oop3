﻿namespace TimeTable.Model
{
    public class Couple
    {
        public string Name { get; set; }
        public string GroupNumber { get; set; }
        public string Faculty { get; set; }
        public string Data { get; set; }
        public string DayOfWeak { get; set; }
        public int CoupleNumber { get; set; }
        public string TypeWork { get; set; }
        public string Type { get; set; }
        public int Count { get; set; }

    }
}